<?php
$_['text_total'] = 'Total';