<?php

$_['paid_on_amazonus_text'] = 'Paid on Amazon US';
$_['shipping_text'] = 'Shipping';
$_['shipping_tax_text'] = 'Shipping tax';
$_['gift_wrap_text'] = 'Gift Wrap';
$_['gift_wrap_tax_text'] = 'Gift Wrap tax';
$_['sub_total_text'] = 'Sub-Total';
$_['tax_text'] = 'Tax';
$_['total_text'] = 'Total'; 