<?php
// Heading  
$_['heading_title']          = 'Bossthemes Cart';

// Text
$_['text_title']             = 'Product added to Cart';
$_['text_thumb']             = '<img src="%s" alt="" />';
$_['text_success']           = '<a href="%s">%s</a> added to <a href="%s" class="cart">shopping cart</a>';
$_['text_items']             = '%s item(s) - %s';

// Error
$_['error_required']         = '%s required!';	

?>