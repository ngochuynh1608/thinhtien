<?php
// Text
$_['text_items']    = '%s sản phẩm - %s';
$_['text_empty']    = 'Không có sản phẩm trong giỏ hàng!';
$_['text_cart']     = 'Xem chi tiết giỏ hàng';
$_['text_checkout'] = 'Thanh toán';
$_['text_recurring']  = 'Chi trả theo kỳ';