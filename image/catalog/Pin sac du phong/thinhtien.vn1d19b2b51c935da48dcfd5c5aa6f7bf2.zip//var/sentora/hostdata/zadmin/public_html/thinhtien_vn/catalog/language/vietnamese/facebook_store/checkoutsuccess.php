<?php
// Heading
$_['heading_title'] = 'Đơn đặt hàng của bạn đã được tạo thành công!';

// Text
$_['text_customer'] = '<p>Chúc mừng! Bạn vừa đặt hàng thành công!</p><p>Nếu có thắc mắc, bạn vui lòng liên hệ <a href="%s">bộ phận chăm sóc khách hàng</a>.</p><p>Cám ơn bạn đã mua hàng của chúng tôi!</p>';
$_['text_guest']    = '<p>Your order has been successfully processed!</p><p>Please direct any questions you have to the <a href="%s">store owner</a>.</p><p>Thanks for shopping with us online!</p>';
$_['text_basket']   = 'Basket';
$_['text_checkout'] = 'Checkout';
$_['text_success']  = 'Success';
?>