<?php
// Text
$_['text_subject']     = 'New comment added';
$_['text_message']     = 'New comment was added on Facebook Store. \n\nLogin to your Facebook account (admin) if you want to moderate comments.';


?> 