<?php
// Text
$_['text_information']  = 'Thông tin';
$_['text_about']        = 'Giới thiệu';
$_['text_service']      = 'Chăm sóc khách hàng';
$_['text_extra']        = 'Chức năng khác';
$_['text_contact']      = 'Liên hệ';
$_['text_return']       = 'Trả hàng';
$_['text_sitemap']      = 'Sơ đồ trang';
$_['text_manufacturer'] = 'Thương hiệu';
$_['text_voucher']      = 'Phiếu quà tặng';
$_['text_affiliate']    = 'Đại lý';
$_['text_special']      = 'Khuyến mại';
$_['text_account']      = 'Tài khoản của tôi';
$_['text_order']        = 'Lịch sử đặt hàng';
$_['text_wishlist']     = 'Sản phẩm ưa thích';
$_['text_newsletter']   = 'Thư thông báo';
$_['text_livestream']   = 'FB LiveStream';
$_['text_login']        = 'Đăng nhập';
$_['text_register']     = 'Tạo Tài khoản';
$_['text_invite_friends_msg']= 'Cùng mình khám phá gian hàng này nhé! Có rất nhiều sản phẩm hấp dẫn và các chương trình đặc biệt dành cho khách hàng thân thiết và khách hàng VIP đó!';
$_['text_powered']      = 'Bản quyền của <a href="http://TENSHOP.com">TÊN SHOP</a><br /> %s &copy; %s';
?>