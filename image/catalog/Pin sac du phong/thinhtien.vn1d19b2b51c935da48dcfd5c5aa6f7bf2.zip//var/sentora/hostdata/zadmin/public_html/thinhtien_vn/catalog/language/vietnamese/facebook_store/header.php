<?php
// Text
$_['text_home']     = 'Trang chủ';
$_['text_wishlist'] = 'Yêu thích (%s)';
$_['text_cart']     = 'Giỏ hàng';
$_['text_items']    = '%s item(s) - %s';
$_['text_search']   = 'Tìm kiếm';
$_['text_welcome']  = 'Chào bạn! Bạn có thể <a href="%s">Đăng nhập</a> hoặc <a href="%s">Đăng ký tài khoản</a>.';
$_['text_logged']   = 'Bạn đã đăng nhập với tên <a href="%s">%s</a> <b>(</b> <a href="%s">Thoát ra</a> <b>)</b>';
$_['text_account']  = 'Tài khoản của tôi';
$_['text_checkout'] = 'Thanh toán';
$_['text_language'] = 'Ngôn ngữ';
$_['text_currency'] = 'Tiền tệ';
$_['text_livestream'] = 'LiveStream';
$_['text_contact']  = 'Liên hệ';
$_['text_all_products'] = 'Tất cả sản phẩm';
?> 