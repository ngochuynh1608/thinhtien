<?php
// Heading
$_['heading_title'] = 'Customer Reviews';

// Text
$_['text_empty'] = 'No Any Reviews!';
?>