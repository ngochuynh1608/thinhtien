<?php
// Heading 
$_['heading_title']      = 'Simple Support';

// Text
$_['text_no_faq_found']		= 'No Faq Found!';
$_['text_support_ticket']		= 'Support Ticket';
?>